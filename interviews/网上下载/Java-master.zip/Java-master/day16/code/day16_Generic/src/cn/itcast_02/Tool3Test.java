package cn.itcast_02;

public class Tool3Test {
	public static void main(String[] args) {
		Tool3 t = new Tool3();

		t.print("hello");
		t.print(100);
		t.print(true);
	}
}
