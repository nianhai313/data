import cn.itcast.txz.ui.MainFrame;


public class App {
	public static void main(String[] args) {
		new MainFrame();
	}
}
