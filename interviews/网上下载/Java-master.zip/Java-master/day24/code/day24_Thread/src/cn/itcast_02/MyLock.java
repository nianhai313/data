package cn.itcast_02;

public class MyLock {
	public static final Object objA = new Object();
	public static final Object objB = new Object();
}
