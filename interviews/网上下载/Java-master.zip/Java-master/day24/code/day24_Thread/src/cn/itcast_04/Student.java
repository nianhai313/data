package cn.itcast_04;

public class Student {
	String name;
	int age;
}
